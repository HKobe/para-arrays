(function() {
  "use strict"
  //this defines an array of HTML Elements
  
var paragraphElements = [];
 paragraphElements[0] = document.getElementById("bio");
 paragraphElements[1] = document.getElementById("projects");
 paragraphElements[2] = document.getElementById("about");

 //defines your paragraph array
  var paragraphs = [];
  //The data for my pages
  paragraphs [0] = "Hassan...";
  paragraphs [1] = "Ghassan...";
  paragraphs [2] = "Kobeissi";
  //second way to define an array
  //var paragraph = new  array();
  //checks to see if paragraph one exists
   for (var index = 0; index < paragraphElements.length; index++)
   {
     if (paragraphElements[index]) {
  paragraphElements[index].textContent = paragraphs[index];
  }
   }

  })();